﻿using System;

namespace RecipeApp
{
    class Recipe
    {
        // array for storing each ingredient and information 
        private string[] ingredientNames;
        private double[] ingredientQuantities;
        private string[] ingredientUnits;
        private string[] steps;

        //TutorialsTeacher
        //2023
        //https://www.tutorialsteacher.com/csharp/csharp-arraylist
        public Recipe()
        {
            Console.WriteLine("Enter the number of ingredients:");
            int numIngredients = int.Parse(Console.ReadLine());
            ingredientNames = new string[numIngredients];
            ingredientQuantities = new double[numIngredients];
            ingredientUnits = new string[numIngredients];
            //for loop that runs through how many ingredients you added
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter the name of ingredient #{i + 1}:");
                ingredientNames[i] = Console.ReadLine();
                Console.WriteLine($"Enter the quantity of ingredient #{i + 1}:");
                ingredientQuantities[i] = double.Parse(Console.ReadLine());
                Console.WriteLine($"Enter the unit of measurement for ingredient #{i + 1}:");
                ingredientUnits[i] = Console.ReadLine();
            }
            //steps
            Console.WriteLine("Enter the number of steps:");
            int numSteps = int.Parse(Console.ReadLine());
            steps = new string[numSteps];
            //loop through each step
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step #{i + 1}:");
                steps[i] = Console.ReadLine();
            }
        }
        //new method for printing reciepe 
        public void PrintRecipe()
        {
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < ingredientNames.Length; i++)
            {
                Console.WriteLine($"{ingredientNames[i]}: {ingredientQuantities[i]} {ingredientUnits[i]}");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < ingredientQuantities.Length; i++)
            {
                ingredientQuantities[i] *= factor;
            }
        }

        public void ResetQuantities()
        {
            for (int i = 0; i < ingredientQuantities.Length; i++)
            {
                ingredientQuantities[i] /= 2;
            }
        }

        public void ClearRecipe()
        {
            Array.Clear(ingredientNames, 0, ingredientNames.Length);
            Array.Clear(ingredientQuantities, 0, ingredientQuantities.Length);
            Array.Clear(ingredientUnits, 0, ingredientUnits.Length);
            Array.Clear(steps, 0, steps.Length);
        }
    }
    // class to run program
    class Program
    //Vithal Wadje
    //c# corner
    //2023
    //https://www.c-sharpcorner.com/UploadFile/0c1bb2/types-of-classes-in-C-Sharp1/
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();
            //w3tutorials
            //2023
            //https://www.w3schools.com/cs/cs_for_loop.php
            while (true)
            {
                Console.WriteLine("Enter a command (p: print, s: scale, r: reset, c: clear, q: quit):");
                string command = Console.ReadLine();

                if (command == "p")
                {
                    recipe.PrintRecipe();
                }
                else if (command == "s")
                {
                    Console.WriteLine("Enter scale factor (0.5, 2, or 3):");
                    double factor = double.Parse(Console.ReadLine());
                    recipe.ScaleRecipe(factor);
                }
                else if (command == "r")
                {
                    recipe.ResetQuantities();
                }
                else if (command == "c")
                {
                    recipe.ClearRecipe();
                    recipe = new Recipe();
                }
                else if (command == "q")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid command.");
                }
            }
        }
    }
}

